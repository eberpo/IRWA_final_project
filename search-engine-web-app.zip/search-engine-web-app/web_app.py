import os
from json import JSONEncoder
import re
# pip install httpagentparser
import httpagentparser  # for getting the user agent as json
import nltk
from flask import Flask, render_template, session
from flask import request

from myapp.analytics.analytics_data import AnalyticsData, SessionData, RequestData, ClickData
from myapp.search.load_corpus import load_corpus
from myapp.search.objects import Document, StatsDocument
from myapp.search.search_engine import SearchEngine
from myapp.search.objects import ResultItem
from datetime import datetime
import random


click_data = []
# *** for using method to_json in objects ***
def _default(self, obj):
    return getattr(obj.__class__, "to_json", _default.default)(obj)


_default.default = JSONEncoder().default
JSONEncoder.default = _default

# end lines ***for using method to_json in objects ***

# instantiate the Flask application
app = Flask(__name__)

# random 'secret_key' is used for persisting data in secure cookie
app.secret_key = 'afgsreg86sr897b6st8b76va8er76fcs6g8d7'
# open browser dev tool to see the cookies
app.session_cookie_name = 'IRWA_SEARCH_ENGINE'

session_id = 'Session' + str(72345)

# instantiate our in memory persistence
analytics_data = AnalyticsData()

# print("current dir", os.getcwd() + "\n")
# print("__file__", __file__ + "\n")
full_path = os.path.realpath(__file__)
path, filename = os.path.split(full_path)
#print(path + ' --> ' + filename + "\n")
# load documents corpus into memory.
file_path = path + "/data/farmers-protest-tweets.json"

# file_path = "../../tweets-data-who.json"

corpus = load_corpus(file_path)

# instantiate our search engine
search_engine = SearchEngine()

# Home URL "/"
@app.route('/')
def index():
    print("starting home url /...")

    # flask server creates a session by persisting a cookie in the user's browser.
    # the 'session' object keeps data between multiple requests
    session['some_var'] = "IRWA 2021 home"

    user_agent = request.headers.get('User-Agent')
    print("Raw user browser:", user_agent)

    user_ip = request.remote_addr
    agent = httpagentparser.detect(user_agent)

    print("Remote IP: {} - JSON user browser {}".format(user_ip, agent))

    print(session)

    return render_template('index.html', page_title="Welcome")


@app.route('/search', methods=['POST'])
def search_form_post():
    search_query = request.form['search-query']
    session['last_search_query'] = search_query
    analytics_data.increment_session_search_count(session_id)

    # Save query terms or increment query frequency
    search_id = analytics_data.save_query_terms(search_query)
    analytics_data.increment_query_frequency(search_id)

    # Prepare results
    docs = []
    ranked_documents, results = search_engine.search(search_query, search_id, corpus)
    for doc_id in ranked_documents:
        doc = corpus[doc_id]
        ref = f"doc_details?id={doc.id}&search_id={search_id}&param2=2"
        docs.append(ResultItem(
            doc.id, doc.content, doc.user, doc.date, doc.lang,
            doc.likes, doc.retweets, doc.url, doc.tokenize_content, doc.hashtags, ref
        ))

    session['last_found_count'] = len(results)
    analytics_data.save_search_results(search_id, ranked_documents)
    return render_template('results.html', results_list=docs, page_title="Results", found_counter=len(results))



@app.route('/doc_details', methods=['GET'])
def doc_details():
    clicked_doc_id = int(request.args["id"])
    search_id = int(request.args["search_id"])

    # Use stored search results to determine ranking
    ranked_doc_ids = list(analytics_data.search_results[search_id].keys())  # Extract IDs in ranked order
    ranking = ranked_doc_ids.index(clicked_doc_id) + 1 if clicked_doc_id in ranked_doc_ids else None

    #ranking = ranked_docs.index(clicked_doc_id) + 1 if clicked_doc_id in ranked_docs else None
    dwell_time = 0

    # Capture user-agent details
    user_agent_info = httpagentparser.detect(request.headers.get('User-Agent'))
    click_data_instance = ClickData(
        click_id=f"Click{random.randint(0, 100000)}",
        session_id=session_id,
        doc_id=clicked_doc_id,
        click_counter=analytics_data.fact_clicks.get(clicked_doc_id, 0),
        query_id=search_id,
        ranking=ranking,
        dwell_time=dwell_time,
        query_name=session.get('last_search_query', ''),
        browser=user_agent_info.get('browser', {}).get('name', 'Unknown browser'),
        operating_system=user_agent_info.get('os', {}).get('name', 'Unknown OS'),
        timestamp=datetime.now()
    )
    analytics_data.record_click(click_data_instance)

    content = re.sub(r'https?://\S+|www\.\S+', '', corpus[clicked_doc_id].content)
    return render_template(
        'doc_details.html',
        content=content,
        likes=corpus[clicked_doc_id].likes,
        retweets=corpus[clicked_doc_id].retweets,
        date=corpus[clicked_doc_id].date,
        url=corpus[clicked_doc_id].url
    )

@app.route('/update_dwell_time', methods=['POST'])
def update_dwell_time():
    """
    Update dwell time for a document.
    """
    try:
        # Ensure JSON payload is parsed correctly
        data = request.get_json(force=True)  # Force parsing JSON even if the Content-Type header is incorrect
        doc_id = data.get('doc_id')
        dwell_time = data.get('dwell_time')

        # Validate inputs
        if not doc_id or not dwell_time:
            return 'Invalid data', 400

        # Log the dwell time (add to analytics)
        for click in analytics_data.all_click_data:
            if click.doc_id == int(doc_id) and click.session_id == session_id:
                click.dwell_time += dwell_time  # Update dwell time for this document

        return '', 204  # Success: No Content
    except Exception as e:
        print(f"Error processing dwell time: {e}")
        return 'Error', 500


@app.route('/stats', methods=['GET'])
def stats():
    """
    Display detailed statistics about searches, clicks, and session data.
    """
    # Prepare document statistics (clicked documents)
    docs = [
        StatsDocument(
            corpus[int(doc_id)].id,
            corpus[int(doc_id)].content,
            corpus[int(doc_id)].date,
            corpus[int(doc_id)].url,
            count
        )
        for doc_id, count in analytics_data.fact_clicks.items()
    ]

    # Prepare search statistics (queries)
    search = [
        RequestData(
            request_id=search_id,
            query_name=data["query"],
            query_length=len(data["query"].split()),
            freq_query=data["frequency"],
            url=request.url,
            method=request.method,
            headers=list(request.headers),
            timestamp=datetime.now()
        )
        for search_id, data in analytics_data.fact_queries.items()
    ]

    # Prepare session data
    session_num_clicks = sum(analytics_data.fact_clicks.values())
    session_search_count = analytics_data.session_search_counts.get(session_id, 0)
    session_data = SessionData(
        session_id=session_id,
        num_searches=session_search_count,
        num_clicks=session_num_clicks,
        user_agent=request.headers.get('User-Agent'),
        ip_address=request.remote_addr,
        timestamp=datetime.now()
    )

    # Sort documents by click count in descending order
    docs.sort(key=lambda doc: doc.count, reverse=True)

    # Render the statistics page with the prepared data
    return render_template(
        'stats.html',
        stats_docs=docs,
        clicks_data=analytics_data.all_click_data,
        queries_data=search,
        session_data=session_data
    )


# @app.route('/dashboard', methods=['GET'])
# def dashboard():
#     visited_docs = []
#     print(analytics_data.fact_clicks.keys())
#     for doc_id in analytics_data.fact_clicks.keys():
#         d: Document = corpus[int(doc_id)]
#         doc = ClickedDoc(doc_id, d.description, analytics_data.fact_clicks[doc_id])
#         visited_docs.append(doc)

#     # simulate sort by ranking
#     visited_docs.sort(key=lambda doc: doc.counter, reverse=True)

#     for doc in visited_docs: print(doc)
#     return render_template('dashboard.html', visited_docs=visited_docs)


@app.route('/dashboard', methods=['GET'])
def dashboard():
    """
    Render the dashboard page with graphs based on analytics data.
    """
    #click count by document
    document_clicks = [
        {"doc_id": doc_id, "clicks": count}
        for doc_id, count in analytics_data.fact_clicks.items()
    ]
    query_frequencies = [
        {"query": data["query"], "frequency": data["frequency"]}
        for _, data in analytics_data.fact_queries.items()
    ]

    # Dwell Time by Document
    dwell_times = {}
    for click in analytics_data.all_click_data:
        if click.doc_id not in dwell_times:
            dwell_times[click.doc_id] = click.dwell_time
        else:
            dwell_times[click.doc_id] += click.dwell_time
    document_dwell_times = [
        {"doc_id": doc_id, "dwell_time": dwell_time}
        for doc_id, dwell_time in dwell_times.items()
    ]


    return render_template('dashboard.html',
                           document_clicks=document_clicks,
                           query_frequencies=query_frequencies,
                           document_dwell_times=document_dwell_times)


@app.route('/sentiment')
def sentiment_form():
    return render_template('sentiment.html')


@app.route('/sentiment', methods=['POST'])
def sentiment_form_post():
    text = request.form['text']
    nltk.download('vader_lexicon')
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    sid = SentimentIntensityAnalyzer()
    score = ((sid.polarity_scores(str(text)))['compound'])
    return render_template('sentiment.html', score=score)


if __name__ == "__main__":
    app.run(port=8080, host="0.0.0.0", threaded=False, debug=True)

