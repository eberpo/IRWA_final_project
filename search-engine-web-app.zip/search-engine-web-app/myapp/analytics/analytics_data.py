import json
import random
from datetime import datetime

class AnalyticsData:
    def __init__(self):
        self.fact_clicks = {}
        self.fact_queries = {}
        self.session_search_counts = {}
        self.all_click_data = []
        self.search_results = {}  # New: {search_id: ranked_document_ids}

    def save_search_results(self, search_id, ranked_documents):
        """
        Save the ranked results of a search for ranking statistics.
        """
        self.search_results[search_id] = ranked_documents

    def save_query_terms(self, terms: str) -> int:
        """
        Saves a query and assigns it a unique ID.
        """
        search_id = random.randint(0, 100000)
        self.fact_queries[search_id] = {
            "query": terms,
            "frequency": 1
        }
        return search_id

    def increment_query_frequency(self, search_id):
        """
        Increment the frequency of a query by its search ID.
        """
        if search_id in self.fact_queries:
            self.fact_queries[search_id]["frequency"] += 1

    def record_click(self, click_data):
        """
        Records a click and updates related statistics.
        """
        doc_id = click_data.doc_id
        if doc_id in self.fact_clicks:
            self.fact_clicks[doc_id] += 1
        else:
            self.fact_clicks[doc_id] = 1
        self.all_click_data.append(click_data)

    def increment_session_search_count(self, session_id):
        """
        Increment the search count for a session.
        """
        if session_id in self.session_search_counts:
            self.session_search_counts[session_id] += 1
        else:
            self.session_search_counts[session_id] = 1
            
class ClickData:
    def __init__(self, click_id, session_id, doc_id, click_counter, query_id, ranking, dwell_time, query_name, browser, operating_system, timestamp):
        self.click_id = click_id
        self.session_id = session_id
        self.doc_id = doc_id
        self.click_counter = click_counter
        self.query_id = query_id
        self.ranking = ranking
        self.dwell_time = dwell_time  # Time spent on page
        self.query_name = query_name
        self.browser = browser
        self.operating_system = operating_system
        self.timestamp = timestamp

    def to_json(self):
        return json.dumps(self.__dict__, default=str)


class RequestData:
    def __init__(self, request_id, query_name, query_length, freq_query, url, method, headers, timestamp):
        self.request_id = request_id
        self.query_name = query_name
        self.query_length = query_length
        self.freq_query = freq_query
        self.url = url
        self.method = method
        self.headers = headers
        self.timestamp = timestamp

    def to_json(self):
        return json.dumps(self.__dict__, default=str)


class SessionData:
    def __init__(self, session_id, num_searches, num_clicks, user_agent, ip_address, timestamp):
        self.session_id = session_id
        self.num_searches = num_searches
        self.num_clicks = num_clicks
        self.user_agent = user_agent
        self.ip_address = ip_address
        self.timestamp = timestamp

    def to_json(self):
        return json.dumps(self.__dict__, default=str)
