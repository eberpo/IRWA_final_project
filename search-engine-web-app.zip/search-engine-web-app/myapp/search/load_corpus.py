import json
from .objects import Document  # Adjust import according to your package structure
from indicnlp.tokenize import indic_tokenize
from punjabi_stopwords import remove_stopwords
from stopwords_hindi import hindi_sw
import emoji
from nltk.corpus import stopwords
import re
from nltk.stem import PorterStemmer
from collections import defaultdict
import pandas as pd


stop_words_english = set(stopwords.words('english'))
stop_words_indonesian = set(stopwords.words('indonesian'))
stop_words_hindi = hindi_sw.get_hindi_sw()

mapping_doc_path = 'data/tweet_document_ids_map.csv'

# Read the CSV file into a pandas DataFrame
df = pd.read_csv(mapping_doc_path)
id_to_number = dict(zip(df['id'], df['docId']))


def remove_emojis(text):
    return emoji.replace_emoji(text, "")

def combine_hashtags(tokens):
    combined_tokens = []
    i = 0

    while i < len(tokens):
        if tokens[i].startswith('#') and i + 1 < len(tokens):
            # Combines de # with the next token
            combined_tokens.append(f"{tokens[i]}{tokens[i + 1]}")
            i += 2
        else:
            combined_tokens.append(tokens[i])
            i += 1

    return combined_tokens

def combine_at(tokens):  #The same code as before but with the @ of the users
  combined_at = []
  i=0

  while i < len(tokens):
    if tokens[i].startswith('@') and i + 1 < len(tokens):
      combined_at.append(f"{tokens[i]}{tokens[i+1]}")
      i += 2
    else:
      combined_at.append(tokens[i])
      i += 1

  return combined_at

def remove_punctuation_mixed(tokens):
    punctuation_list = [',','-','.','|','!','?','!!',':','...','=','/', ';', '(', ')', "'", "।"]
    punct_pattern = r"^[{}]+|[{}]+$".format(re.escape(''.join(punctuation_list)), re.escape(''.join(punctuation_list)))
    cleaned_tokens = []

    for token in tokens:
        # Remove punctuation using regex
        cleaned_token = re.sub(punct_pattern, '', token)
        # Add the cleaned token
        cleaned_tokens.append(cleaned_token)

    return cleaned_tokens

def build_terms(tweet):
    """
    Preprocess the tweet text (removing stop words, stemming,
    transforming to lowercase and returning the tokens).

    Arguments:
    tweet -- dictionary containing 'content' (text) and 'lang' (language)

    Returns:
    tokens - a list of tokens corresponding to the input text after preprocessing
    """

    line = tweet['content']
    lang = tweet['lang']

    stemmer = PorterStemmer()

    # Transform to lowercase
    line = line.lower()
    line = remove_emojis(line) #additionally we decided to also remove emojis from the text, since they are not relevant for the search
    line = re.sub(r"'", '', line)

    url_pattern = r'https?://\S+|www\.\S+'
    urls = re.findall(url_pattern, line)
    # Remove URLs #
    line = re.sub(url_pattern, '', line)

    # Tokenize based on the language
    if lang in ['pa', 'hi']:  # Hindi and Punjabi
        tokens = indic_tokenize.trivial_tokenize(line)  # Tokenize for Punjabi
        tokens = combine_hashtags(tokens)
        tokens = combine_at(tokens)
    else:  # English and Indonesian
        tokens = line.split()

    tokens = remove_punctuation_mixed(tokens)


    # Remove stopwords based on language
    if lang == 'en':
        tokens = [x for x in tokens if x not in stop_words_english]
    elif lang == 'id':
        tokens = [x for x in tokens if x not in stop_words_indonesian]
    elif lang == 'hi':
        tokens = [x for x in tokens if x not in stop_words_hindi]
    elif lang == 'pa':
        # Join tokens into a single string for stopword removal
        text_string = ' '.join(tokens)
        filtered_text = remove_stopwords(text_string)  # Remove stopwords
        tokens = filtered_text.split()

    tokens = [x for x in tokens if x not in [',','-','.','|','!','?','!!',':','...','=','/', ';', '(', ')', "'", "।", '\n', '', '_', '"','&amp', '\n\n']] #extra layer of purification upon inspecting the most frequent tokens
    # Perform stemming
    tokens = [stemmer.stem(x) for x in tokens]

    return tokens, urls

def find_pattern(tweet, pattern):
    hashtags = []
    for token in tweet:
        if re.match(pattern, token):
            hashtags.append(token)
    return hashtags


def load_corpus(file_path):
    """
    Load and preprocess tweet data from a JSON file.

    Args:
        file_path (str): Path to the JSON file containing the tweets.

    Returns:
        dict: A dictionary of Tweet objects indexed by tweet ID.
    """
    with open(file_path, 'r') as file:
        tweets_data = [json.loads(line) for line in file]

    corpus = {}
    for tweet_data in tweets_data:
        if tweet_data['id'] in id_to_number.keys():
            id=tweet_data['id']
            content=tweet_data['content']
            user=tweet_data['user']['username']
            date=tweet_data['date']
            lang=tweet_data['lang']
            likes=tweet_data['likeCount']
            retweets=tweet_data['retweetCount']
            url=tweet_data['url']
            tokenize_content, URL = list(build_terms(tweet_data))
            hashtags = find_pattern(tokenize_content, r'^#')
            tweet = Document(id, content, user, date, lang, likes, retweets, url, tokenize_content, hashtags)
            corpus[tweet.id] = tweet
            
    return corpus
