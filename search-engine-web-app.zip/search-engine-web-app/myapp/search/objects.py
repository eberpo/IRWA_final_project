import json

class Document:
    """
    Original corpus data as an object
    """

    def __init__(self, id, content, user, date ,lang, likes, retweets, url, tokenize_content, hashtags):
        self.id = id
        self.content = content
        self.user = user
        self.date = date
        self.lang = lang
        self.likes = likes
        self.retweets = retweets
        self.url = url
        self.tokenize_content = tokenize_content
        self.hashtags = hashtags


    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)


class StatsDocument:
    """
    Original corpus data as an object
    """

    def __init__(self, id, content, date, url, count):
        self.id = id
        self.content = content
        self.date = date
        self.url = url
        self.count = count

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)


class ResultItem:
    def __init__(self, id, content, user, date, lang, likes, retweets, url, tokenize_content, hashtags, ref):
        self.id = id
        self.content = content
        self.user = user
        self.date = date
        self.lang = lang
        self.likes = likes
        self.retweets = retweets
        self.url = url
        self.tokenize_content = tokenize_content
        self.hashtags = hashtags
        self.ref = ref
