from collections import defaultdict
from .load_corpus import  combine_hashtags, remove_emojis, remove_punctuation_mixed, combine_at
from sklearn.preprocessing import MinMaxScaler
from indicnlp.tokenize import indic_tokenize
from punjabi_stopwords import remove_stopwords
from stopwords_hindi import hindi_sw
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import numpy as np
import re

stop_words_english = set(stopwords.words('english'))
stop_words_indonesian = set(stopwords.words('indonesian'))
stop_words_hindi = hindi_sw.get_hindi_sw()


def search_in_corpus(query, corpus, inverted_index):
    
    # 1. create create_tfidf_index
    # 2. apply ranking
    query_terms = build_terms_query(query)
    num_tweets = len(corpus)
    lines = []
    for tweet_id in corpus:
        tweet = corpus[tweet_id]
        processed_line, url_line = build_terms(tweet)
        line = [tweet_id, processed_line]
        lines.append(line)

    ranked_docs, result_scores = custom_score_cosine(query_terms, corpus, inverted_index)

    return ranked_docs, result_scores

def build_terms_query(query, lang='en'):
  line = query

  stemmer = PorterStemmer()

  # Transform to lowercase
  line = line.lower()
  line = remove_emojis(line) #additionally we decided to also remove emojis from the text, since they are not relevant for the search
  line = re.sub(r"'", '', line)


  line = re.sub(r'https://[^\s]+', '', line)

  # Tokenize based on the language
  if lang in ['pa', 'hi']:  # Hindi and Punjabi
      tokens = indic_tokenize.trivial_tokenize(line)  # Tokenize for Punjabi
      tokens = combine_hashtags(tokens)
      tokens = combine_at(tokens)
  else:  # English and Indonesian
      tokens = line.split()

  tokens = remove_punctuation_mixed(tokens)

  # Remove stopwords based on language
  if lang == 'en':
      tokens = [x for x in tokens if x not in stop_words_english]
  elif lang == 'id':
      tokens = [x for x in tokens if x not in stop_words_indonesian]
  elif lang == 'hi':
      tokens = [x for x in tokens if x not in stop_words_hindi]
  elif lang == 'pa':
      # Join tokens into a single string for stopword removal
      text_string = ' '.join(tokens)
      filtered_text = remove_stopwords(text_string)  # Remove stopwords
      tokens = filtered_text.split()

  tokens = [x for x in tokens if x not in [',','-','.','|','!','?','!!',':','...','=','/', ';', '(', ')', "'", "।", '\n', '', '_', '"','&amp', '\n\n']] #extra layer of purification upon inspecting the most frequent tokens
  # Perform stemming
  tokens = [stemmer.stem(x) for x in tokens]

  return tokens

def custom_score_cosine(query_terms, corpus, inverted_index, alpha=0.5, beta=0.3, gamma=0.2):
    tweets_scores = defaultdict(float)
    total_tweets = len(corpus)

    tweet_candidates = set(inverted_index[query_terms[0]])
    for item in query_terms[1:]:
        tweet_candidates &= set(inverted_index[item])
   
    query_tfidf = defaultdict(float)

    query_term_counts = {term: query_terms.count(term) for term in set(query_terms)}

    for term, term_frequency in query_term_counts.items():
        if term in inverted_index:
            df = len(inverted_index[term])
            if df > 0:
                idf = np.log(total_tweets / df)
            else:
                idf = 0 
            tf = term_frequency / len(query_terms)
            query_tfidf[term] = tf * idf

    likes = np.array([corpus[tweet_id].likes for tweet_id in tweet_candidates])
    retweets = np.array([corpus[tweet_id].retweets for tweet_id in tweet_candidates])

    # Apply Min-Max Scaling
    scaler = MinMaxScaler()
    if likes.size > 0:
        normalized_likes = scaler.fit_transform(likes.reshape(-1, 1)).flatten()
    else:
        print("Likes array is empty! Assigning default zero values.")
        normalized_likes = np.zeros(len(tweet_candidates))

    if retweets.size > 0:
        normalized_retweets = scaler.fit_transform(retweets.reshape(-1, 1)).flatten()
    else:
        print("Retweets array is empty! Assigning default zero values.")
        normalized_retweets = np.zeros(len(tweet_candidates))

    # Create mappings of normalized values for each doc_id
    likes_map = dict(zip(tweet_candidates, normalized_likes))
    retweets_map = dict(zip(tweet_candidates, normalized_retweets))

    for tweet_id in tweet_candidates:
        tweet_tfidf = defaultdict(float)
        for term in set(corpus[tweet_id].tokenize_content):
            if term in inverted_index:
                df = len(inverted_index[term])
                idf = np.log(total_tweets/df)
                term_frequency = corpus[tweet_id].tokenize_content.count(term)
                tf = term_frequency/ len(corpus[tweet_id].tokenize_content)
                tweet_tfidf[term] = tf*idf

        tweet_magnitude = np.sqrt(sum(value ** 2 for value in tweet_tfidf.values()))
        if tweet_magnitude != 0:
            normalized_doc_tfidf = {term: value / tweet_magnitude for term, value in tweet_tfidf.items()}

        else:
              normalized_doc_tfidf = tweet_tfidf
        #cosine similarity
        dot_product = sum(query_tfidf[term] * normalized_doc_tfidf.get(term, 0) for term in query_terms)

        if  tweet_magnitude != 0:
            # Retrieve normalized popularity scores
            normalized_likes = likes_map[tweet_id]
            normalized_retweets = retweets_map[tweet_id]
            popularity_score = (alpha * dot_product) + (beta * normalized_likes) + (gamma * normalized_retweets)
            
            tweets_scores[tweet_id] = popularity_score

    ranked_tweets = dict(sorted(tweets_scores.items(), key=lambda x: x[1], reverse=True))
    return ranked_tweets, tweets_scores



def build_terms(tweet):
    """
    Preprocess the tweet text (removing stop words, stemming,
    transforming to lowercase and returning the tokens).

    Arguments:
    tweet -- dictionary containing 'content' (text) and 'lang' (language)

    Returns:
    tokens - a list of tokens corresponding to the input text after preprocessing
    """

    line = tweet.content
    lang = tweet.lang

    stemmer = PorterStemmer()

    # Transform to lowercase
    line = line.lower()
    line = remove_emojis(line) #additionally we decided to also remove emojis from the text, since they are not relevant for the search
    line = re.sub(r"'", '', line)

    url_pattern = r'https?://\S+|www\.\S+'
    urls = re.findall(url_pattern, line)
    # Remove URLs #
    line = re.sub(url_pattern, '', line)

    # Tokenize based on the language
    if lang in ['pa', 'hi']:  # Hindi and Punjabi
        tokens = indic_tokenize.trivial_tokenize(line)  # Tokenize for Punjabi
        tokens = combine_hashtags(tokens)
        tokens = combine_at(tokens)
    else:  # English and Indonesian
        tokens = line.split()

    tokens = remove_punctuation_mixed(tokens)


    # Remove stopwords based on language
    if lang == 'en':
        tokens = [x for x in tokens if x not in stop_words_english]
    elif lang == 'id':
        tokens = [x for x in tokens if x not in stop_words_indonesian]
    elif lang == 'hi':
        tokens = [x for x in tokens if x not in stop_words_hindi]
    elif lang == 'pa':
        # Join tokens into a single string for stopword removal
        text_string = ' '.join(tokens)
        filtered_text = remove_stopwords(text_string)  # Remove stopwords
        tokens = filtered_text.split()

    tokens = [x for x in tokens if x not in [',','-','.','|','!','?','!!',':','...','=','/', ';', '(', ')', "'", "।", '\n', '', '_', '"','&amp', '\n\n']] #extra layer of purification upon inspecting the most frequent tokens
    # Perform stemming
    tokens = [stemmer.stem(x) for x in tokens]

    return tokens, urls
