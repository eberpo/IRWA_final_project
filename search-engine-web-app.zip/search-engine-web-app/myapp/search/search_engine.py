import random 

from myapp.search.objects import ResultItem, Document
from myapp.search.algorithms import search_in_corpus, custom_score_cosine
from collections import defaultdict

def build_inverted_index(corpus):
    inverted_index = defaultdict(list)

    for tweet_id, tweet_data in corpus.items():
        tokens = corpus[tweet_id].tokenize_content
        for token in tokens:
            if tweet_id not in inverted_index[token]:
                inverted_index[token].append(tweet_id)

    return inverted_index


class SearchEngine:
    """educational search engine"""

    def search(self, search_query, search_id, _corpus):
        print("Search query:", search_query)

        results = []
        ##### your code here #####
        inverted_index = build_inverted_index(_corpus)
        # results = build_demo_results(corpus, search_id)  # replace with call to search algorithm
        ranked_documents, results = search_in_corpus(search_query, _corpus, inverted_index)
        
        return  ranked_documents, results

      #  return [ResultItem(item.id, item.title, item.description, item.doc_date,
      #                     "doc_details?id={}&search_id={}&param2=2".format(item.id, search_id), score)
      #          for item, score in zip(documents, results)]